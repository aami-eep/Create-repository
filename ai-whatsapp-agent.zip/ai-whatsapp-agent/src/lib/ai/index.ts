import type { AIGenerateInput, AIGenerateResult, AIProviderId } from "@/types";
import type { AISettings } from "@/types";
import { getProvider } from "@/lib/ai/registry";
import { AI_PROVIDER_PRIORITY, DEFAULT_MODELS } from "@/lib/ai/config";

export { AI_PROVIDERS, getProvider } from "@/lib/ai/registry";
export * from "@/lib/ai/config";

interface ProviderCredentials {
  apiKey: string;
  model: string;
}

function resolveCredentials(
  settings: Pick<
    AISettings,
    | "gemini_api_key"
    | "qwen_api_key"
    | "deepseek_api_key"
    | "gemini_model"
    | "qwen_model"
    | "deepseek_model"
  >,
  provider: AIProviderId
): ProviderCredentials | null {
  const map: Record<AIProviderId, ProviderCredentials | null> = {
    gemini: settings.gemini_api_key
      ? { apiKey: settings.gemini_api_key, model: settings.gemini_model || DEFAULT_MODELS.gemini }
      : null,
    qwen: settings.qwen_api_key
      ? { apiKey: settings.qwen_api_key, model: settings.qwen_model || DEFAULT_MODELS.qwen }
      : null,
    deepseek: settings.deepseek_api_key
      ? {
          apiKey: settings.deepseek_api_key,
          model: settings.deepseek_model || DEFAULT_MODELS.deepseek,
        }
      : null,
  };
  return map[provider];
}

/**
 * الدالة الموحّدة الوحيدة التي يجب على أي جزء من التطبيق استدعاؤها لتوليد رد.
 *
 * تحاول أولاً استخدام المزود المختار في إعدادات الشركة، وإذا فشل (لعدم توفر
 * مفتاح API أو لخطأ في الاتصال) تنتقل تلقائياً إلى المزود التالي حسب ترتيب
 * الأولوية المحدد في lib/ai/config.ts، دون الحاجة لأي تعديل في الكود.
 */
export async function generateReply(
  settings: AISettings,
  input: AIGenerateInput
): Promise<AIGenerateResult & { triedProviders: AIProviderId[] }> {
  const ordered: AIProviderId[] = [
    settings.provider,
    ...AI_PROVIDER_PRIORITY.filter((p) => p !== settings.provider),
  ];

  const triedProviders: AIProviderId[] = [];
  let lastError: AIGenerateResult | null = null;

  for (const providerId of ordered) {
    const credentials = resolveCredentials(settings, providerId);
    if (!credentials) continue;

    triedProviders.push(providerId);
    const provider = getProvider(providerId);
    const result = await provider.generate(credentials.apiKey, credentials.model, input);

    if (result.success) {
      return { ...result, triedProviders };
    }
    lastError = result;
  }

  return (
    lastError
      ? { ...lastError, triedProviders }
      : {
          success: false,
          provider: settings.provider,
          error: "لا يوجد أي مزود ذكاء اصطناعي مُفعّل. الرجاء إضافة مفتاح API واحد على الأقل.",
          triedProviders,
        }
  );
}
