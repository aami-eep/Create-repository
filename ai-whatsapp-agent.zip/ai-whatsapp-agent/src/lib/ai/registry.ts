import type { AIProviderId } from "@/types";
import type { AIProvider } from "@/lib/ai/types";
import { geminiProvider } from "@/lib/ai/providers/gemini";
import { qwenProvider } from "@/lib/ai/providers/qwen";
import { deepseekProvider } from "@/lib/ai/providers/deepseek";

/**
 * Registry of every available AI provider. To add a new provider, implement
 * the AIProvider interface and add one line here + one entry in the
 * AIProviderId union (src/types/index.ts). Nothing else needs to change.
 */
export const AI_PROVIDERS: Record<AIProviderId, AIProvider> = {
  gemini: geminiProvider,
  qwen: qwenProvider,
  deepseek: deepseekProvider,
};

export function getProvider(id: AIProviderId): AIProvider {
  const provider = AI_PROVIDERS[id];
  if (!provider) throw new Error(`AI provider غير معروف: ${id}`);
  return provider;
}
