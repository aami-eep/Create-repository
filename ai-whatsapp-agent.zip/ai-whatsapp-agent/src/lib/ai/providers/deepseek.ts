import type { AIProvider } from "@/lib/ai/types";
import { DEFAULT_MODELS } from "@/lib/ai/config";
import { generateWithOpenAICompatible, testOpenAICompatible } from "./openai-compatible";

const BASE_URL = "https://api.deepseek.com";

export const deepseekProvider: AIProvider = {
  id: "deepseek",
  label: "DeepSeek",
  defaultModel: DEFAULT_MODELS.deepseek,

  generate(apiKey, model, input) {
    return generateWithOpenAICompatible({
      providerId: "deepseek",
      baseUrl: BASE_URL,
      apiKey,
      model: model || DEFAULT_MODELS.deepseek,
      input,
    });
  },

  testConnection(apiKey, model) {
    return testOpenAICompatible({
      baseUrl: BASE_URL,
      apiKey,
      model: model || DEFAULT_MODELS.deepseek,
    });
  },
};
