import type { AIGenerateInput, AIGenerateResult } from "@/types";
import type { AIProvider } from "@/lib/ai/types";
import { DEFAULT_MODELS } from "@/lib/ai/config";

const BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models";

export const geminiProvider: AIProvider = {
  id: "gemini",
  label: "Google Gemini",
  defaultModel: DEFAULT_MODELS.gemini,

  async generate(apiKey, model, input: AIGenerateInput): Promise<AIGenerateResult> {
    const started = Date.now();
    const modelId = model || DEFAULT_MODELS.gemini;

    try {
      const contents = [
        ...(input.history ?? []).map((m) => ({
          role: m.role === "assistant" ? "model" : "user",
          parts: [{ text: m.content }],
        })),
        { role: "user", parts: [{ text: input.userMessage }] },
      ];

      const res = await fetch(`${BASE_URL}/${modelId}:generateContent?key=${apiKey}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contents,
          systemInstruction: { parts: [{ text: input.systemPrompt }] },
          generationConfig: { temperature: 0.6, maxOutputTokens: 512 },
        }),
      });

      const data = await res.json();

      if (!res.ok) {
        return {
          success: false,
          provider: "gemini",
          error: data?.error?.message || `Gemini API error (${res.status})`,
          latencyMs: Date.now() - started,
        };
      }

      const reply = data?.candidates?.[0]?.content?.parts?.[0]?.text?.trim();

      if (!reply) {
        return {
          success: false,
          provider: "gemini",
          error: "لم يتم استلام رد نصي من Gemini.",
          latencyMs: Date.now() - started,
        };
      }

      return { success: true, provider: "gemini", reply, latencyMs: Date.now() - started };
    } catch (err) {
      return {
        success: false,
        provider: "gemini",
        error: err instanceof Error ? err.message : "خطأ غير معروف في الاتصال بـ Gemini",
        latencyMs: Date.now() - started,
      };
    }
  },

  async testConnection(apiKey, model) {
    const modelId = model || DEFAULT_MODELS.gemini;
    try {
      const res = await fetch(`${BASE_URL}/${modelId}:generateContent?key=${apiKey}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contents: [{ role: "user", parts: [{ text: "ping" }] }],
          generationConfig: { maxOutputTokens: 8 },
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        return { success: false, error: data?.error?.message || `فشل الاتصال (${res.status})` };
      }
      return { success: true };
    } catch (err) {
      return { success: false, error: err instanceof Error ? err.message : "فشل الاتصال" };
    }
  },
};
