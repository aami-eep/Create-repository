import type { AIProvider } from "@/lib/ai/types";
import { DEFAULT_MODELS } from "@/lib/ai/config";
import { generateWithOpenAICompatible, testOpenAICompatible } from "./openai-compatible";

// DashScope's OpenAI-compatible mode (works for both mainland & international keys).
const BASE_URL = "https://dashscope-intl.aliyuncs.com/compatible-mode/v1";

export const qwenProvider: AIProvider = {
  id: "qwen",
  label: "Alibaba Qwen",
  defaultModel: DEFAULT_MODELS.qwen,

  generate(apiKey, model, input) {
    return generateWithOpenAICompatible({
      providerId: "qwen",
      baseUrl: BASE_URL,
      apiKey,
      model: model || DEFAULT_MODELS.qwen,
      input,
    });
  },

  testConnection(apiKey, model) {
    return testOpenAICompatible({ baseUrl: BASE_URL, apiKey, model: model || DEFAULT_MODELS.qwen });
  },
};
