import type { AIGenerateInput, AIGenerateResult, AIProviderId } from "@/types";

/**
 * Qwen (Alibaba DashScope) and DeepSeek both expose an OpenAI-compatible
 * "/chat/completions" endpoint, so we share one implementation and only
 * change the base URL + provider id per provider file.
 */
export async function generateWithOpenAICompatible(opts: {
  providerId: AIProviderId;
  baseUrl: string;
  apiKey: string;
  model: string;
  input: AIGenerateInput;
}): Promise<AIGenerateResult> {
  const { providerId, baseUrl, apiKey, model, input } = opts;
  const started = Date.now();

  try {
    const messages = [
      { role: "system", content: input.systemPrompt },
      ...(input.history ?? []).map((m) => ({ role: m.role, content: m.content })),
      { role: "user", content: input.userMessage },
    ];

    const res = await fetch(`${baseUrl}/chat/completions`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model,
        messages,
        temperature: 0.6,
        max_tokens: 512,
      }),
    });

    const data = await res.json();

    if (!res.ok) {
      return {
        success: false,
        provider: providerId,
        error: data?.error?.message || `خطأ من الخادم (${res.status})`,
        latencyMs: Date.now() - started,
      };
    }

    const reply = data?.choices?.[0]?.message?.content?.trim();

    if (!reply) {
      return {
        success: false,
        provider: providerId,
        error: "لم يتم استلام رد نصي من المزود.",
        latencyMs: Date.now() - started,
      };
    }

    return { success: true, provider: providerId, reply, latencyMs: Date.now() - started };
  } catch (err) {
    return {
      success: false,
      provider: providerId,
      error: err instanceof Error ? err.message : "خطأ غير معروف في الاتصال",
      latencyMs: Date.now() - started,
    };
  }
}

export async function testOpenAICompatible(opts: {
  baseUrl: string;
  apiKey: string;
  model: string;
}): Promise<{ success: boolean; error?: string }> {
  const { baseUrl, apiKey, model } = opts;
  try {
    const res = await fetch(`${baseUrl}/chat/completions`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model,
        messages: [{ role: "user", content: "ping" }],
        max_tokens: 8,
      }),
    });
    const data = await res.json();
    if (!res.ok) {
      return { success: false, error: data?.error?.message || `فشل الاتصال (${res.status})` };
    }
    return { success: true };
  } catch (err) {
    return { success: false, error: err instanceof Error ? err.message : "فشل الاتصال" };
  }
}
