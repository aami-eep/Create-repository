import type { AIGenerateInput, AIGenerateResult } from "@/types";

/**
 * Every AI provider (Gemini, Qwen, DeepSeek, ...) must implement this
 * single interface. The rest of the app never talks to a provider's SDK
 * or REST API directly - it always goes through this contract.
 *
 * To add a new provider:
 *   1. Create a new file in src/lib/ai/providers/<name>.ts implementing this interface.
 *   2. Register it in src/lib/ai/registry.ts.
 *   3. Add its id to the AIProviderId union in src/types/index.ts.
 * No other file in the project needs to change.
 */
export interface AIProvider {
  readonly id: string;
  readonly label: string;
  readonly defaultModel: string;

  /** Generates a reply to a customer message given a system prompt. */
  generate(apiKey: string, model: string, input: AIGenerateInput): Promise<AIGenerateResult>;

  /** Performs a minimal call to verify the API key/model are valid. */
  testConnection(apiKey: string, model: string): Promise<{ success: boolean; error?: string }>;
}
