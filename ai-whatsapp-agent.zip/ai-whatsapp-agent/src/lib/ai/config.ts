import type { AIProviderId } from "@/types";

/**
 * ---------------------------------------------------------------------------
 * نقطة التحكم الوحيدة في مزودي الذكاء الاصطناعي.
 * غيّر المزود الافتراضي أو ترتيب الأولوية من هنا فقط - لا حاجة لتعديل أي
 * ملف آخر في المشروع.
 * ---------------------------------------------------------------------------
 */

/** المزود المستخدم افتراضياً عند عدم وجود إعداد محفوظ لشركة ما. */
export const DEFAULT_AI_PROVIDER: AIProviderId = "gemini";

/** ترتيب الأولوية: يُستخدم كترتيب عرض في الواجهة وكخطة احتياطية. */
export const AI_PROVIDER_PRIORITY: AIProviderId[] = ["gemini", "qwen", "deepseek"];

/** النماذج الافتراضية لكل مزود - يمكن تغييرها من صفحة إعدادات الذكاء الاصطناعي أيضاً. */
export const DEFAULT_MODELS: Record<AIProviderId, string> = {
  gemini: "gemini-2.0-flash",
  qwen: "qwen-plus",
  deepseek: "deepseek-chat",
};

export const PROVIDER_LABELS: Record<AIProviderId, string> = {
  gemini: "Google Gemini",
  qwen: "Alibaba Qwen",
  deepseek: "DeepSeek",
};

export const PROVIDER_DOCS_URL: Record<AIProviderId, string> = {
  gemini: "https://aistudio.google.com/apikey",
  qwen: "https://dashscope.console.aliyun.com/apiKey",
  deepseek: "https://platform.deepseek.com/api_keys",
};
