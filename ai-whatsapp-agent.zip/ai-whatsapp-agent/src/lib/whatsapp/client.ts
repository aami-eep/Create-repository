/**
 * ---------------------------------------------------------------------------
 * طبقة WhatsApp Business Cloud API - مستقلة تماماً عن باقي المشروع.
 *
 * هذه الطبقة "جاهزة وغير مفعّلة" في النسخة الأولى. تفعيلها لاحقاً لا يتطلب
 * أي تعديل في باقي الملفات: فقط أضف متغيرات البيئة الخاصة بواتساب واضبط
 * WHATSAPP_ENABLED=true، ثم اربط رقم الهاتف من Meta for Developers.
 * ---------------------------------------------------------------------------
 */

const GRAPH_API_VERSION = "v21.0";

export const isWhatsAppEnabled = () => process.env.WHATSAPP_ENABLED === "true";

interface SendMessageParams {
  phoneNumberId: string;
  accessToken: string;
  to: string;
  text: string;
}

/** يرسل رسالة نصية إلى عميل عبر WhatsApp Business Cloud API. */
export async function sendWhatsAppMessage({
  phoneNumberId,
  accessToken,
  to,
  text,
}: SendMessageParams): Promise<{ success: boolean; error?: string }> {
  if (!isWhatsAppEnabled()) {
    return { success: false, error: "ربط واتساب غير مفعّل بعد في هذه النسخة." };
  }

  try {
    const res = await fetch(
      `https://graph.facebook.com/${GRAPH_API_VERSION}/${phoneNumberId}/messages`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${accessToken}`,
        },
        body: JSON.stringify({
          messaging_product: "whatsapp",
          to,
          type: "text",
          text: { body: text },
        }),
      }
    );

    const data = await res.json();
    if (!res.ok) {
      return { success: false, error: data?.error?.message || "فشل إرسال الرسالة" };
    }
    return { success: true };
  } catch (err) {
    return { success: false, error: err instanceof Error ? err.message : "فشل إرسال الرسالة" };
  }
}

/** يتحقق من طلب التحقق الأولي (Webhook Verification) الذي يرسله Meta. */
export function verifyWebhookChallenge(
  params: URLSearchParams,
  expectedVerifyToken: string
): { ok: true; challenge: string } | { ok: false } {
  const mode = params.get("hub.mode");
  const token = params.get("hub.verify_token");
  const challenge = params.get("hub.challenge");

  if (mode === "subscribe" && token === expectedVerifyToken && challenge) {
    return { ok: true, challenge };
  }
  return { ok: false };
}

/** بنية رسالة واردة مبسّطة بعد استخراجها من حمولة Webhook الخام. */
export interface IncomingWhatsAppMessage {
  from: string;
  text: string;
  phoneNumberId: string;
}

/** يستخرج الرسائل النصية الواردة من حمولة Webhook الخام الخاصة بـ Meta. */
export function parseIncomingWebhook(payload: any): IncomingWhatsAppMessage[] {
  const messages: IncomingWhatsAppMessage[] = [];

  try {
    for (const entry of payload?.entry ?? []) {
      for (const change of entry?.changes ?? []) {
        const value = change?.value;
        const phoneNumberId = value?.metadata?.phone_number_id;
        for (const msg of value?.messages ?? []) {
          if (msg.type === "text" && msg.text?.body) {
            messages.push({ from: msg.from, text: msg.text.body, phoneNumberId });
          }
        }
      }
    }
  } catch {
    // حمولة غير متوقعة - نتجاهلها بأمان.
  }

  return messages;
}
