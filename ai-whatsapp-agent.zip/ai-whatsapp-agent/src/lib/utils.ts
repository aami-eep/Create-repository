import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/** Builds the system prompt sent to the AI model from the business profile. */
export function buildSystemPrompt(business: {
  name: string;
  description?: string | null;
  services?: string | null;
  products?: string | null;
  prices?: string | null;
  faq?: string | null;
  working_hours?: string | null;
  location?: string | null;
  phone?: string | null;
  ai_instructions?: string | null;
}) {
  const lines: string[] = [];

  lines.push(
    `أنت مساعد ذكاء اصطناعي يرد نيابة عن "${business.name}" على استفسارات العملاء عبر واتساب.`
  );
  lines.push("تحدث بلغة العميل، بأسلوب ودود ومهني ومختصر، وكأنك موظف خدمة عملاء حقيقي.");

  if (business.description) lines.push(`نبذة عن الشركة: ${business.description}`);
  if (business.services) lines.push(`الخدمات المقدمة: ${business.services}`);
  if (business.products) lines.push(`المنتجات: ${business.products}`);
  if (business.prices) lines.push(`الأسعار: ${business.prices}`);
  if (business.faq) lines.push(`الأسئلة الشائعة وإجاباتها:\n${business.faq}`);
  if (business.working_hours) lines.push(`ساعات العمل: ${business.working_hours}`);
  if (business.location) lines.push(`الموقع: ${business.location}`);
  if (business.phone) lines.push(`رقم التواصل: ${business.phone}`);
  if (business.ai_instructions)
    lines.push(`تعليمات خاصة يجب الالتزام بها دائماً: ${business.ai_instructions}`);

  lines.push(
    "إذا لم تجد إجابة واضحة في المعلومات أعلاه، اعتذر بلطف واقترح على العميل التواصل المباشر مع الشركة عبر رقم الهاتف المذكور بدل اختلاق معلومات."
  );
  lines.push("اجعل الردود قصيرة ومباشرة ومناسبة لمحادثة واتساب.");

  return lines.join("\n");
}

export function formatDateTime(iso: string) {
  return new Date(iso).toLocaleString("ar", {
    dateStyle: "medium",
    timeStyle: "short",
  });
}
