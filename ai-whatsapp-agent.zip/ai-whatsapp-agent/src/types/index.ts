// ---------------------------------------------------------------------------
// Domain types shared across the whole application.
// ---------------------------------------------------------------------------

export type AIProviderId = "gemini" | "qwen" | "deepseek";

export interface AIProviderConfig {
  provider: AIProviderId;
  apiKey: string;
  model?: string;
}

export interface AIGenerateInput {
  systemPrompt: string;
  userMessage: string;
  history?: { role: "user" | "assistant"; content: string }[];
}

export interface AIGenerateResult {
  success: boolean;
  reply?: string;
  error?: string;
  provider: AIProviderId;
  latencyMs?: number;
}

export interface Business {
  id: string;
  owner_id: string;
  name: string;
  description: string | null;
  services: string | null;
  products: string | null;
  prices: string | null;
  faq: string | null;
  working_hours: string | null;
  location: string | null;
  phone: string | null;
  ai_instructions: string | null;
  created_at: string;
  updated_at: string;
}

export interface AISettings {
  id: string;
  business_id: string;
  provider: AIProviderId;
  gemini_api_key: string | null;
  qwen_api_key: string | null;
  deepseek_api_key: string | null;
  gemini_model: string | null;
  qwen_model: string | null;
  deepseek_model: string | null;
  is_connected: boolean;
  updated_at: string;
}

export type WhatsAppConnectionStatus = "disconnected" | "pending" | "connected" | "error";

export interface WhatsAppConnection {
  id: string;
  business_id: string;
  phone_number_id: string | null;
  waba_id: string | null;
  access_token: string | null;
  verify_token: string | null;
  status: WhatsAppConnectionStatus;
  created_at: string;
  updated_at: string;
}

export interface ConversationMessage {
  id: string;
  business_id: string;
  customer_phone: string;
  direction: "inbound" | "outbound";
  content: string;
  provider: AIProviderId | null;
  created_at: string;
}

export interface DashboardStats {
  businessName: string;
  isConnected: boolean;
  totalReplies: number;
  lastMessages: ConversationMessage[];
}
