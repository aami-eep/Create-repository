import { BrainCircuit, Building2, Clock, PlugZap, ShieldCheck, TestTube2 } from "lucide-react";

const features = [
  {
    icon: Building2,
    title: "ملف شركة كامل",
    desc: "أدخل خدماتك، منتجاتك، أسعارك، وأسئلتك الشائعة مرة واحدة، ويعتمد عليها الذكاء الاصطناعي في كل رد.",
  },
  {
    icon: BrainCircuit,
    title: "تعدد مزودي الذكاء الاصطناعي",
    desc: "اختر بين Gemini أو Qwen أو DeepSeek، وبدّل بينهم في أي وقت من الإعدادات دون أي تعقيد.",
  },
  {
    icon: PlugZap,
    title: "تبديل تلقائي عند التعطل",
    desc: "إذا لم يستجب مزود معيّن، ينتقل النظام تلقائياً للمزود التالي حسب أولويتك دون انقطاع الخدمة.",
  },
  {
    icon: TestTube2,
    title: "صفحة اختبار مباشرة",
    desc: "جرّب ردود الذكاء الاصطناعي على رسائل حقيقية قبل ربط رقم واتساب فعلياً.",
  },
  {
    icon: Clock,
    title: "متاح على مدار الساعة",
    desc: "لا إجازات ولا أوقات ذروة — عملاؤك يحصلون على رد فوري ودقيق في أي وقت.",
  },
  {
    icon: ShieldCheck,
    title: "بياناتك محمية",
    desc: "كل شركة ترى بياناتها فقط بفضل سياسات الحماية على مستوى الصفوف في قاعدة البيانات.",
  },
];

export function Features() {
  return (
    <section id="features" className="mx-auto max-w-6xl px-6 py-20">
      <div className="mb-14 max-w-xl">
        <p className="mb-3 text-sm font-medium text-brand-500">المميزات</p>
        <h2 className="text-balance font-display text-3xl font-bold md:text-4xl">
          كل ما تحتاجه لتشغيل خدمة عملاء ذكية
        </h2>
      </div>

      <div className="grid gap-px overflow-hidden rounded-2xl border border-line-light dark:border-line bg-line-light dark:bg-line md:grid-cols-3">
        {features.map(({ icon: Icon, title, desc }) => (
          <div key={title} className="bg-canvas-light dark:bg-canvas p-7">
            <div className="mb-4 flex h-10 w-10 items-center justify-center rounded-xl bg-brand-500/10 text-brand-500">
              <Icon size={18} />
            </div>
            <h3 className="mb-2 font-display text-base font-semibold">{title}</h3>
            <p className="text-sm leading-relaxed text-ink-soft">{desc}</p>
          </div>
        ))}
      </div>
    </section>
  );
}
