import Link from "next/link";
import { ArrowLeft, MessageCircle } from "lucide-react";
import { Button } from "@/components/ui/button";

export function CTA() {
  return (
    <section className="mx-auto max-w-6xl px-6 py-24 text-center">
      <h2 className="mx-auto max-w-lg text-balance font-display text-3xl font-bold md:text-4xl">
        جاهز تخلي واتساب بيزنس يرد لحاله؟
      </h2>
      <p className="mx-auto mt-4 max-w-md text-ink-soft">
        سجّل الآن مجاناً، وجرّب المساعد الذكي على معلومات شركتك خلال دقائق.
      </p>
      <div className="mt-8 flex justify-center">
        <Link href="/login">
          <Button size="lg">
            ابدأ الآن مجاناً
            <ArrowLeft size={16} />
          </Button>
        </Link>
      </div>
    </section>
  );
}

export function Footer() {
  return (
    <footer className="border-t border-line-light dark:border-line">
      <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-4 px-6 py-8 md:flex-row">
        <div className="flex items-center gap-2">
          <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-ink dark:bg-brand-500 text-canvas-light dark:text-white">
            <MessageCircle size={14} strokeWidth={2.5} />
          </span>
          <span className="font-display text-sm font-bold">AI WhatsApp Agent</span>
        </div>
        <p className="text-xs text-ink-soft">
          © {new Date().getFullYear()} AI WhatsApp Agent. جميع الحقوق محفوظة.
        </p>
      </div>
    </footer>
  );
}
