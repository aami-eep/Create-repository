import Link from "next/link";
import { ArrowLeft, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ChatMockup } from "@/components/landing/chat-mockup";

export function Hero() {
  return (
    <section className="mx-auto grid max-w-6xl items-center gap-16 px-6 py-20 md:grid-cols-2 md:py-28">
      <div>
        <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-line-light dark:border-line px-3 py-1 text-xs text-ink-soft">
          <Sparkles size={13} className="text-brand-500" />
          مدعوم بـ Gemini · Qwen · DeepSeek
        </div>

        <h1 className="text-balance font-display text-4xl font-extrabold leading-[1.15] md:text-5xl">
          دع الذكاء الاصطناعي يرد على عملائك في واتساب،
          <span className="text-brand-500"> على مدار الساعة</span>
        </h1>

        <p className="mt-6 max-w-md text-balance text-lg leading-relaxed text-ink-soft">
          اربط رقم واتساب بيزنس الخاص بشركتك أو متجرك أو مطعمك أو عيادتك، وزوّد
          الذكاء الاصطناعي بمعلوماتك — وسيتولى الرد على استفسارات عملائك فوراً
          وبدقة، بدون تدخل يدوي.
        </p>

        <div className="mt-8 flex items-center gap-4">
          <Link href="/login">
            <Button size="lg">
              ابدأ مجاناً
              <ArrowLeft size={16} />
            </Button>
          </Link>
          <a href="#how">
            <Button variant="outline" size="lg">
              شاهد كيف يعمل
            </Button>
          </a>
        </div>

        <div className="mt-10 flex items-center gap-6 text-sm text-ink-soft">
          <div>
            <p className="font-display text-2xl font-bold text-ink dark:text-ink-inverted">3</p>
            <p>مزودو ذكاء اصطناعي</p>
          </div>
          <div className="h-8 w-px bg-line-light dark:bg-line" />
          <div>
            <p className="font-display text-2xl font-bold text-ink dark:text-ink-inverted">دقائق</p>
            <p>للإعداد والانطلاق</p>
          </div>
        </div>
      </div>

      <ChatMockup />
    </section>
  );
}
