import Link from "next/link";
import { MessageCircle } from "lucide-react";
import { ThemeToggle } from "@/components/theme-toggle";
import { Button } from "@/components/ui/button";

export function LandingNavbar() {
  return (
    <header className="sticky top-0 z-50 border-b border-line-light dark:border-line bg-canvas-light/80 dark:bg-canvas/80 backdrop-blur-md">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
        <Link href="/" className="flex items-center gap-2">
          <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-ink dark:bg-brand-500 text-canvas-light dark:text-white">
            <MessageCircle size={16} strokeWidth={2.5} />
          </span>
          <span className="font-display text-[15px] font-bold">AI WhatsApp Agent</span>
        </Link>

        <nav className="hidden items-center gap-8 md:flex">
          <a href="#features" className="text-sm text-ink-soft hover:text-ink dark:hover:text-ink-inverted transition-colors">
            المميزات
          </a>
          <a href="#how" className="text-sm text-ink-soft hover:text-ink dark:hover:text-ink-inverted transition-colors">
            كيف يعمل
          </a>
        </nav>

        <div className="flex items-center gap-3">
          <ThemeToggle />
          <Link href="/login">
            <Button variant="ghost" size="sm">
              تسجيل الدخول
            </Button>
          </Link>
          <Link href="/login">
            <Button size="sm">ابدأ الآن</Button>
          </Link>
        </div>
      </div>
    </header>
  );
}
