const steps = [
  {
    n: "01",
    title: "أنشئ حسابك",
    desc: "سجّل دخولك بالبريد الإلكتروني فقط — بدون كلمات مرور ولا تعقيد.",
  },
  {
    n: "02",
    title: "عرّف شركتك",
    desc: "أدخل اسم الشركة، خدماتها، أسعارها، وساعات عملها في صفحة الإعدادات.",
  },
  {
    n: "03",
    title: "فعّل الذكاء الاصطناعي",
    desc: "اختر المزود الذي تريده وأدخل مفتاح API الخاص بك، واختبر الاتصال بضغطة واحدة.",
  },
  {
    n: "04",
    title: "اربط واتساب",
    desc: "بعد التجربة في صفحة الاختبار، اربط رقم واتساب بيزنس ليبدأ الرد التلقائي.",
  },
];

export function HowItWorks() {
  return (
    <section id="how" className="border-y border-line-light dark:border-line bg-canvas-lightSoft dark:bg-canvas-soft/40">
      <div className="mx-auto max-w-6xl px-6 py-20">
        <div className="mb-14 max-w-xl">
          <p className="mb-3 text-sm font-medium text-brand-500">خطوات العمل</p>
          <h2 className="text-balance font-display text-3xl font-bold md:text-4xl">
            من التسجيل إلى أول رد آلي في أقل من 10 دقائق
          </h2>
        </div>

        <div className="grid gap-8 md:grid-cols-4">
          {steps.map((step, i) => (
            <div key={step.n} className="relative">
              <p className="mb-4 font-display text-4xl font-extrabold text-line-light dark:text-line">
                {step.n}
              </p>
              <h3 className="mb-2 font-display text-base font-semibold">{step.title}</h3>
              <p className="text-sm leading-relaxed text-ink-soft">{step.desc}</p>
              {i < steps.length - 1 && (
                <div className="absolute top-5 -left-4 hidden h-px w-8 bg-line-light dark:bg-line md:block" />
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
