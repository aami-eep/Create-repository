import { Check, CheckCheck } from "lucide-react";

const exchange = [
  { from: "customer", text: "السلام عليكم، ايش أوقات الدوام عندكم؟", time: "10:41" },
  { from: "ai", text: "وعليكم السلام ومرحباً بك 🌿 نستقبلكم يومياً من الساعة 9 صباحاً حتى 11 مساءً.", time: "10:41" },
  { from: "customer", text: "تمام، وهل عندكم توصيل؟", time: "10:42" },
  { from: "ai", text: "أكيد! التوصيل متوفر داخل المدينة خلال 30-45 دقيقة، والرسوم 10 ريال فقط.", time: "10:42" },
];

export function ChatMockup() {
  return (
    <div className="relative mx-auto w-full max-w-sm">
      <div className="absolute -inset-6 -z-10 rounded-[3rem] bg-brand-400/20 blur-3xl" />

      <div className="overflow-hidden rounded-[2rem] border border-line-light dark:border-line bg-[#0B141A] shadow-2xl">
        {/* WhatsApp-style header */}
        <div className="flex items-center gap-3 bg-[#1F2C34] px-4 py-3">
          <div className="flex h-9 w-9 items-center justify-center rounded-full bg-brand-500 text-sm font-bold text-white">
            AI
          </div>
          <div className="flex-1">
            <p className="text-sm font-semibold text-white">مقهى الأصالة</p>
            <p className="text-[11px] text-signal-green">متصل الآن — يرد الذكاء الاصطناعي</p>
          </div>
        </div>

        {/* Chat body */}
        <div
          className="flex flex-col gap-2.5 px-3 py-4"
          style={{
            backgroundImage:
              "radial-gradient(circle at 20% 20%, rgba(255,255,255,0.02) 0, transparent 40%), radial-gradient(circle at 80% 60%, rgba(255,255,255,0.02) 0, transparent 40%)",
            backgroundColor: "#0B141A",
          }}
        >
          {exchange.map((msg, i) => (
            <div
              key={i}
              className={`flex animate-fadeUp ${msg.from === "ai" ? "justify-start" : "justify-end"}`}
              style={{ animationDelay: `${i * 0.35}s`, animationFillMode: "backwards" }}
            >
              <div
                className={`max-w-[78%] rounded-2xl px-3 py-2 text-[13px] leading-relaxed ${
                  msg.from === "ai"
                    ? "rounded-tl-sm bg-[#202C33] text-[#E9EDEF]"
                    : "rounded-tr-sm bg-[#005C4B] text-[#E9EDEF]"
                }`}
              >
                <p>{msg.text}</p>
                <div className="mt-1 flex items-center justify-end gap-1 text-[10px] text-[#8696A0]">
                  <span>{msg.time}</span>
                  {msg.from === "customer" && <CheckCheck size={13} className="text-[#53BDEB]" />}
                </div>
              </div>
            </div>
          ))}

          <div
            className="flex items-center gap-1.5 self-start rounded-2xl rounded-tl-sm bg-[#202C33] px-3 py-2.5 animate-fadeUp"
            style={{ animationDelay: "1.4s", animationFillMode: "backwards" }}
          >
            <span className="h-1.5 w-1.5 animate-pulseSlow rounded-full bg-[#8696A0]" />
            <span className="h-1.5 w-1.5 animate-pulseSlow rounded-full bg-[#8696A0]" style={{ animationDelay: "0.2s" }} />
            <span className="h-1.5 w-1.5 animate-pulseSlow rounded-full bg-[#8696A0]" style={{ animationDelay: "0.4s" }} />
          </div>
        </div>
      </div>
    </div>
  );
}
