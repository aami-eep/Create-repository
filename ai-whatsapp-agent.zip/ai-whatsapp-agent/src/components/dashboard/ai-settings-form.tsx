"use client";

import { useState } from "react";
import { createSupabaseBrowserClient } from "@/lib/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CheckCircle2, XCircle, ExternalLink } from "lucide-react";
import type { AISettings, AIProviderId } from "@/types";
import { AI_PROVIDER_PRIORITY, PROVIDER_LABELS, PROVIDER_DOCS_URL, DEFAULT_MODELS } from "@/lib/ai/config";

type FieldStatus = "idle" | "testing" | "success" | "error";

export function AISettingsForm({ settings }: { settings: AISettings }) {
  const [form, setForm] = useState<AISettings>(settings);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [testStatus, setTestStatus] = useState<Record<AIProviderId, FieldStatus>>({
    gemini: "idle",
    qwen: "idle",
    deepseek: "idle",
  });
  const [testError, setTestError] = useState<Record<AIProviderId, string>>({
    gemini: "",
    qwen: "",
    deepseek: "",
  });

  function keyField(provider: AIProviderId): keyof AISettings {
    return `${provider}_api_key` as keyof AISettings;
  }
  function modelField(provider: AIProviderId): keyof AISettings {
    return `${provider}_model` as keyof AISettings;
  }

  function updateKey(provider: AIProviderId, value: string) {
    setForm((f) => ({ ...f, [keyField(provider)]: value }));
    setSaved(false);
    setTestStatus((s) => ({ ...s, [provider]: "idle" }));
  }

  async function handleTest(provider: AIProviderId) {
    const apiKey = (form[keyField(provider)] as string) ?? "";
    if (!apiKey) return;

    setTestStatus((s) => ({ ...s, [provider]: "testing" }));
    setTestError((e) => ({ ...e, [provider]: "" }));

    const res = await fetch("/api/ai/test", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        provider,
        apiKey,
        model: (form[modelField(provider)] as string) || DEFAULT_MODELS[provider],
      }),
    });
    const data = await res.json();

    if (data.success) {
      setTestStatus((s) => ({ ...s, [provider]: "success" }));
    } else {
      setTestStatus((s) => ({ ...s, [provider]: "error" }));
      setTestError((e) => ({ ...e, [provider]: data.error || "فشل الاتصال" }));
    }
  }

  async function handleSave(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    const supabase = createSupabaseBrowserClient();

    await supabase
      .from("ai_settings")
      .update({
        provider: form.provider,
        gemini_api_key: form.gemini_api_key,
        qwen_api_key: form.qwen_api_key,
        deepseek_api_key: form.deepseek_api_key,
        gemini_model: form.gemini_model,
        qwen_model: form.qwen_model,
        deepseek_model: form.deepseek_model,
        is_connected: Boolean(form.gemini_api_key || form.qwen_api_key || form.deepseek_api_key),
      })
      .eq("id", settings.id);

    setSaving(false);
    setSaved(true);
  }

  return (
    <form onSubmit={handleSave} className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>المزود النشط</CardTitle>
        </CardHeader>
        <p className="mb-4 text-sm text-ink-soft">
          هذا هو المزود الذي سيُستخدم أولاً. إذا فشل الاتصال به، سينتقل النظام تلقائياً للمزود
          التالي حسب الأولوية من بين المزودين اللذين أدخلت لهما مفتاح API.
        </p>
        <div className="flex flex-wrap gap-3">
          {AI_PROVIDER_PRIORITY.map((provider) => (
            <button
              key={provider}
              type="button"
              onClick={() => {
                setForm((f) => ({ ...f, provider }));
                setSaved(false);
              }}
              className={`rounded-xl border px-4 py-3 text-sm font-medium transition-colors ${
                form.provider === provider
                  ? "border-brand-500 bg-brand-500/10 text-brand-500"
                  : "border-line-light dark:border-line text-ink-soft hover:border-brand-400"
              }`}
            >
              {PROVIDER_LABELS[provider]}
            </button>
          ))}
        </div>
      </Card>

      {AI_PROVIDER_PRIORITY.map((provider) => (
        <Card key={provider}>
          <CardHeader>
            <CardTitle>{PROVIDER_LABELS[provider]}</CardTitle>
            <a
              href={PROVIDER_DOCS_URL[provider]}
              target="_blank"
              rel="noreferrer"
              className="flex items-center gap-1 text-xs text-brand-500 hover:underline"
            >
              الحصول على مفتاح API <ExternalLink size={12} />
            </a>
          </CardHeader>

          <div className="grid gap-4 md:grid-cols-[1fr_auto]">
            <div>
              <Label htmlFor={`${provider}-key`}>مفتاح API</Label>
              <Input
                id={`${provider}-key`}
                type="password"
                dir="ltr"
                placeholder="أدخل مفتاح API هنا"
                value={(form[keyField(provider)] as string) ?? ""}
                onChange={(e) => updateKey(provider, e.target.value)}
              />
            </div>
            <div className="flex items-end">
              <Button
                type="button"
                variant="outline"
                loading={testStatus[provider] === "testing"}
                disabled={!form[keyField(provider)]}
                onClick={() => handleTest(provider)}
              >
                اختبار الاتصال
              </Button>
            </div>
          </div>

          <div className="mt-3">
            <Label htmlFor={`${provider}-model`}>النموذج (اختياري)</Label>
            <Input
              id={`${provider}-model`}
              dir="ltr"
              placeholder={DEFAULT_MODELS[provider]}
              value={(form[modelField(provider)] as string) ?? ""}
              onChange={(e) => setForm((f) => ({ ...f, [modelField(provider)]: e.target.value }))}
            />
          </div>

          {testStatus[provider] === "success" && (
            <Badge tone="success" className="mt-4">
              <CheckCircle2 size={13} /> الاتصال ناجح
            </Badge>
          )}
          {testStatus[provider] === "error" && (
            <Badge tone="danger" className="mt-4">
              <XCircle size={13} /> {testError[provider]}
            </Badge>
          )}
        </Card>
      ))}

      <div className="flex items-center gap-4">
        <Button type="submit" loading={saving}>
          حفظ الإعدادات
        </Button>
        {saved && (
          <span className="flex items-center gap-1.5 text-sm text-signal-green animate-fadeUp">
            <CheckCircle2 size={16} /> تم الحفظ بنجاح
          </span>
        )}
      </div>
    </form>
  );
}
