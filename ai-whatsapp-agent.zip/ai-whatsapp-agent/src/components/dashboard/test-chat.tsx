"use client";

import { useState, useRef, useEffect } from "react";
import { Send, Loader2, Bot, User } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { PROVIDER_LABELS } from "@/lib/ai/config";
import type { AIProviderId } from "@/types";

interface ChatItem {
  role: "user" | "assistant" | "error";
  content: string;
  provider?: AIProviderId;
}

export function TestChat() {
  const [messages, setMessages] = useState<ChatItem[]>([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  async function handleSend(e: React.FormEvent) {
    e.preventDefault();
    const text = input.trim();
    if (!text || loading) return;

    setMessages((m) => [...m, { role: "user", content: text }]);
    setInput("");
    setLoading(true);

    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: text }),
      });
      const data = await res.json();

      if (data.success && data.reply) {
        setMessages((m) => [...m, { role: "assistant", content: data.reply, provider: data.provider }]);
      } else {
        setMessages((m) => [...m, { role: "error", content: data.error || "حدث خطأ في توليد الرد" }]);
      }
    } catch {
      setMessages((m) => [...m, { role: "error", content: "تعذّر الاتصال بالخادم" }]);
    } finally {
      setLoading(false);
    }
  }

  return (
    <Card className="flex h-[600px] flex-col p-0 overflow-hidden">
      <div className="flex-1 overflow-y-auto p-6">
        {messages.length === 0 ? (
          <div className="flex h-full flex-col items-center justify-center gap-3 text-center">
            <span className="flex h-12 w-12 items-center justify-center rounded-full bg-brand-500/10 text-brand-500">
              <Bot size={22} />
            </span>
            <p className="max-w-xs text-sm text-ink-soft">
              اكتب رسالة كأنك عميل، وشاهد كيف سيرد الذكاء الاصطناعي بناءً على بيانات شركتك.
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {messages.map((msg, i) => (
              <div key={i} className={`flex gap-3 ${msg.role === "user" ? "flex-row-reverse" : ""}`}>
                <span
                  className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-full ${
                    msg.role === "user"
                      ? "bg-ink text-canvas-light dark:bg-brand-500 dark:text-white"
                      : msg.role === "error"
                      ? "bg-signal-red/10 text-signal-red"
                      : "bg-brand-500/10 text-brand-500"
                  }`}
                >
                  {msg.role === "user" ? <User size={14} /> : <Bot size={14} />}
                </span>
                <div
                  className={`max-w-[75%] rounded-2xl px-4 py-2.5 text-sm leading-relaxed ${
                    msg.role === "user"
                      ? "rounded-tr-sm bg-ink text-canvas-light dark:bg-brand-500 dark:text-white"
                      : msg.role === "error"
                      ? "rounded-tl-sm bg-signal-red/10 text-signal-red"
                      : "rounded-tl-sm bg-canvas-lightSoft dark:bg-white/5"
                  }`}
                >
                  <p>{msg.content}</p>
                  {msg.provider && (
                    <Badge tone="brand" className="mt-2">
                      {PROVIDER_LABELS[msg.provider]}
                    </Badge>
                  )}
                </div>
              </div>
            ))}
            {loading && (
              <div className="flex items-center gap-2 text-sm text-ink-soft">
                <Loader2 size={14} className="animate-spin" /> جارٍ توليد الرد...
              </div>
            )}
          </div>
        )}
        <div ref={bottomRef} />
      </div>

      <form onSubmit={handleSend} className="flex items-center gap-3 border-t border-line-light dark:border-line p-4">
        <Input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="اكتب رسالة العميل هنا..."
          disabled={loading}
        />
        <Button type="submit" disabled={loading || !input.trim()}>
          <Send size={16} />
        </Button>
      </form>
    </Card>
  );
}
