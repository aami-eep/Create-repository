import { ThemeToggle } from "@/components/theme-toggle";

export function Topbar({ title, email }: { title: string; email?: string }) {
  return (
    <div className="flex items-center justify-between border-b border-line-light dark:border-line px-8 py-5">
      <h1 className="font-display text-xl font-bold">{title}</h1>
      <div className="flex items-center gap-4">
        {email && <span className="text-sm text-ink-soft" dir="ltr">{email}</span>}
        <ThemeToggle />
      </div>
    </div>
  );
}
