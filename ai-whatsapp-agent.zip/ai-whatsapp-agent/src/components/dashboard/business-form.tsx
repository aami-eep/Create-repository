"use client";

import { useState } from "react";
import { createSupabaseBrowserClient } from "@/lib/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { CheckCircle2 } from "lucide-react";
import type { Business } from "@/types";

const fields: { key: keyof Business; label: string; type: "input" | "textarea"; placeholder: string }[] = [
  { key: "name", label: "اسم الشركة", type: "input", placeholder: "مثال: مقهى الأصالة" },
  { key: "description", label: "وصف الشركة", type: "textarea", placeholder: "نبذة مختصرة عن نشاط الشركة..." },
  { key: "services", label: "الخدمات", type: "textarea", placeholder: "اذكر خدماتك، كل خدمة في سطر..." },
  { key: "products", label: "المنتجات", type: "textarea", placeholder: "اذكر منتجاتك الرئيسية..." },
  { key: "prices", label: "الأسعار", type: "textarea", placeholder: "مثال: قهوة عربية - 15 ريال" },
  { key: "faq", label: "الأسئلة الشائعة", type: "textarea", placeholder: "سؤال: ...\nجواب: ..." },
  { key: "working_hours", label: "ساعات العمل", type: "input", placeholder: "يومياً من 9 صباحاً حتى 11 مساءً" },
  { key: "location", label: "الموقع", type: "input", placeholder: "الرياض، حي العليا" },
  { key: "phone", label: "رقم الهاتف", type: "input", placeholder: "+9665xxxxxxxx" },
  {
    key: "ai_instructions",
    label: "تعليمات خاصة للذكاء الاصطناعي",
    type: "textarea",
    placeholder: "مثال: لا تذكر المنافسين، استخدم دائماً لهجة رسمية...",
  },
];

export function BusinessForm({ business }: { business: Business }) {
  const [form, setForm] = useState<Business>(business);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  function update(key: keyof Business, value: string) {
    setForm((f) => ({ ...f, [key]: value }));
    setSaved(false);
  }

  async function handleSave(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    const supabase = createSupabaseBrowserClient();

    await supabase
      .from("businesses")
      .update({
        name: form.name,
        description: form.description,
        services: form.services,
        products: form.products,
        prices: form.prices,
        faq: form.faq,
        working_hours: form.working_hours,
        location: form.location,
        phone: form.phone,
        ai_instructions: form.ai_instructions,
      })
      .eq("id", business.id);

    setSaving(false);
    setSaved(true);
  }

  return (
    <form onSubmit={handleSave} className="space-y-6">
      <Card>
        <div className="grid gap-5 md:grid-cols-2">
          {fields.map((field) => (
            <div key={field.key} className={field.type === "textarea" ? "md:col-span-2" : ""}>
              <Label htmlFor={field.key}>{field.label}</Label>
              {field.type === "input" ? (
                <Input
                  id={field.key}
                  value={(form[field.key] as string) ?? ""}
                  onChange={(e) => update(field.key, e.target.value)}
                  placeholder={field.placeholder}
                />
              ) : (
                <Textarea
                  id={field.key}
                  value={(form[field.key] as string) ?? ""}
                  onChange={(e) => update(field.key, e.target.value)}
                  placeholder={field.placeholder}
                />
              )}
            </div>
          ))}
        </div>
      </Card>

      <div className="flex items-center gap-4">
        <Button type="submit" loading={saving}>
          حفظ التغييرات
        </Button>
        {saved && (
          <span className="flex items-center gap-1.5 text-sm text-signal-green animate-fadeUp">
            <CheckCircle2 size={16} /> تم الحفظ بنجاح
          </span>
        )}
      </div>
    </form>
  );
}
