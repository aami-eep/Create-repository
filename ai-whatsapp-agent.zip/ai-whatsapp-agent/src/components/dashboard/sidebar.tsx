"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { LayoutDashboard, Building2, BrainCircuit, TestTube2, LogOut, MessageCircle } from "lucide-react";
import { createSupabaseBrowserClient } from "@/lib/supabase/client";
import { cn } from "@/lib/utils";

const links = [
  { href: "/dashboard", label: "لوحة التحكم", icon: LayoutDashboard },
  { href: "/dashboard/settings", label: "إعدادات الشركة", icon: Building2 },
  { href: "/dashboard/ai", label: "إعدادات الذكاء الاصطناعي", icon: BrainCircuit },
  { href: "/dashboard/test", label: "صفحة الاختبار", icon: TestTube2 },
];

export function Sidebar() {
  const pathname = usePathname();
  const router = useRouter();

  async function handleSignOut() {
    const supabase = createSupabaseBrowserClient();
    await supabase.auth.signOut();
    router.push("/login");
    router.refresh();
  }

  return (
    <aside className="flex h-screen w-64 shrink-0 flex-col border-l border-line-light dark:border-line bg-canvas-lightSoft dark:bg-canvas-soft/40 px-4 py-6">
      <Link href="/" className="mb-8 flex items-center gap-2 px-2">
        <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-ink dark:bg-brand-500 text-canvas-light dark:text-white">
          <MessageCircle size={16} strokeWidth={2.5} />
        </span>
        <span className="font-display text-[15px] font-bold">AI WhatsApp Agent</span>
      </Link>

      <nav className="flex flex-1 flex-col gap-1">
        {links.map(({ href, label, icon: Icon }) => {
          const active = pathname === href;
          return (
            <Link
              key={href}
              href={href}
              className={cn(
                "flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-colors",
                active
                  ? "bg-ink text-canvas-light dark:bg-brand-500 dark:text-white"
                  : "text-ink-soft hover:bg-black/5 dark:hover:bg-white/5 hover:text-ink dark:hover:text-ink-inverted"
              )}
            >
              <Icon size={17} />
              {label}
            </Link>
          );
        })}
      </nav>

      <button
        onClick={handleSignOut}
        className="flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium text-ink-soft hover:bg-black/5 dark:hover:bg-white/5 hover:text-signal-red transition-colors"
      >
        <LogOut size={17} />
        تسجيل الخروج
      </button>
    </aside>
  );
}
