import { HTMLAttributes } from "react";
import { cn } from "@/lib/utils";

interface BadgeProps extends HTMLAttributes<HTMLSpanElement> {
  tone?: "neutral" | "success" | "warning" | "danger" | "brand";
}

const tones = {
  neutral: "bg-black/5 text-ink-soft dark:bg-white/5 dark:text-ink-inverted/70",
  success: "bg-signal-green/10 text-signal-green",
  warning: "bg-signal-amber/10 text-signal-amber",
  danger: "bg-signal-red/10 text-signal-red",
  brand: "bg-brand-500/10 text-brand-500",
};

export function Badge({ className, tone = "neutral", ...props }: BadgeProps) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-medium",
        tones[tone],
        className
      )}
      {...props}
    />
  );
}
