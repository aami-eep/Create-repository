import { InputHTMLAttributes, forwardRef } from "react";
import { cn } from "@/lib/utils";

export const Input = forwardRef<HTMLInputElement, InputHTMLAttributes<HTMLInputElement>>(
  ({ className, ...props }, ref) => (
    <input
      ref={ref}
      className={cn(
        "w-full h-11 rounded-xl border border-line-light dark:border-line bg-white dark:bg-canvas-soft px-4 text-sm text-ink dark:text-ink-inverted placeholder:text-ink-soft/60 outline-none transition-colors focus:border-brand-400",
        className
      )}
      {...props}
    />
  )
);
Input.displayName = "Input";
