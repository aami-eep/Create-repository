import { ButtonHTMLAttributes, forwardRef } from "react";
import { cn } from "@/lib/utils";
import { Loader2 } from "lucide-react";

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "primary" | "secondary" | "ghost" | "outline" | "danger";
  size?: "sm" | "md" | "lg";
  loading?: boolean;
}

const variants = {
  primary:
    "bg-ink text-canvas-light hover:bg-ink/90 dark:bg-brand-500 dark:text-white dark:hover:bg-brand-600",
  secondary:
    "bg-canvas-lightSoft text-ink hover:bg-line-light dark:bg-canvas-soft dark:text-ink-inverted dark:hover:bg-white/10",
  ghost: "bg-transparent text-ink-soft hover:text-ink dark:hover:text-ink-inverted hover:bg-black/5 dark:hover:bg-white/5",
  outline:
    "bg-transparent border border-line-light dark:border-line text-ink dark:text-ink-inverted hover:border-brand-400",
  danger: "bg-signal-red text-white hover:bg-signal-red/90",
};

const sizes = {
  sm: "h-8 px-3 text-sm",
  md: "h-10 px-4 text-sm",
  lg: "h-12 px-6 text-base",
};

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant = "primary", size = "md", loading, disabled, children, ...props }, ref) => {
    return (
      <button
        ref={ref}
        disabled={disabled || loading}
        className={cn(
          "inline-flex items-center justify-center gap-2 rounded-full font-medium transition-all duration-150 disabled:opacity-50 disabled:cursor-not-allowed active:scale-[0.98]",
          variants[variant],
          sizes[size],
          className
        )}
        {...props}
      >
        {loading && <Loader2 size={16} className="animate-spin" />}
        {children}
      </button>
    );
  }
);
Button.displayName = "Button";
