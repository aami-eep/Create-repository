import { TextareaHTMLAttributes, forwardRef } from "react";
import { cn } from "@/lib/utils";

export const Textarea = forwardRef<HTMLTextAreaElement, TextareaHTMLAttributes<HTMLTextAreaElement>>(
  ({ className, ...props }, ref) => (
    <textarea
      ref={ref}
      className={cn(
        "w-full min-h-[96px] rounded-xl border border-line-light dark:border-line bg-white dark:bg-canvas-soft px-4 py-3 text-sm text-ink dark:text-ink-inverted placeholder:text-ink-soft/60 outline-none transition-colors focus:border-brand-400 resize-y",
        className
      )}
      {...props}
    />
  )
);
Textarea.displayName = "Textarea";
