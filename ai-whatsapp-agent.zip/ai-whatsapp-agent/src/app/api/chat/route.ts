import { NextRequest, NextResponse } from "next/server";
import { createSupabaseServerClient } from "@/lib/supabase/server";
import { generateReply } from "@/lib/ai";
import { buildSystemPrompt } from "@/lib/utils";

/**
 * يستخدمه المستخدم المسجّل دخوله من "صفحة الاختبار" لتجربة رد الذكاء
 * الاصطناعي قبل ربط واتساب. يعتمد على بيانات الشركة وإعدادات الذكاء
 * الاصطناعي المحفوظة في قاعدة البيانات لهذا المستخدم.
 */
export async function POST(req: NextRequest) {
  const supabase = await createSupabaseServerClient();

  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    return NextResponse.json({ error: "غير مصرح" }, { status: 401 });
  }

  const body = await req.json();
  const message: string = (body?.message ?? "").toString().trim();

  if (!message) {
    return NextResponse.json({ error: "الرسالة فارغة" }, { status: 400 });
  }

  const { data: business, error: bErr } = await supabase
    .from("businesses")
    .select("*")
    .eq("owner_id", user.id)
    .single();

  if (bErr || !business) {
    return NextResponse.json({ error: "لم يتم العثور على بيانات الشركة" }, { status: 404 });
  }

  const { data: aiSettings, error: aErr } = await supabase
    .from("ai_settings")
    .select("*")
    .eq("business_id", business.id)
    .single();

  if (aErr || !aiSettings) {
    return NextResponse.json({ error: "لم يتم العثور على إعدادات الذكاء الاصطناعي" }, { status: 404 });
  }

  const systemPrompt = buildSystemPrompt(business);

  const result = await generateReply(aiSettings, {
    systemPrompt,
    userMessage: message,
  });

  return NextResponse.json(result);
}
