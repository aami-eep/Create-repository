import { NextRequest, NextResponse } from "next/server";
import { createSupabaseAdminClient } from "@/lib/supabase/server";
import { generateReply } from "@/lib/ai";
import { buildSystemPrompt } from "@/lib/utils";
import {
  isWhatsAppEnabled,
  parseIncomingWebhook,
  sendWhatsAppMessage,
  verifyWebhookChallenge,
} from "@/lib/whatsapp/client";

/**
 * Webhook خاص بـ WhatsApp Business Cloud API.
 *
 * غير مفعّل في النسخة الأولى (WHATSAPP_ENABLED=false افتراضياً) لكن الملف
 * موجود وجاهز بالكامل - فعّل المتغيرات في .env عند ربط واتساب لاحقاً دون
 * الحاجة لتعديل أي كود.
 */

// خطوة التحقق الأولى التي يطلبها Meta عند إعداد الـ Webhook.
export async function GET(req: NextRequest) {
  if (!isWhatsAppEnabled()) {
    return NextResponse.json({ error: "ربط واتساب غير مفعّل" }, { status: 404 });
  }

  const verifyToken = process.env.WHATSAPP_VERIFY_TOKEN || "";
  const result = verifyWebhookChallenge(req.nextUrl.searchParams, verifyToken);

  if (result.ok) {
    return new NextResponse(result.challenge, { status: 200 });
  }
  return NextResponse.json({ error: "فشل التحقق" }, { status: 403 });
}

// استقبال الرسائل الفعلية من العملاء.
export async function POST(req: NextRequest) {
  if (!isWhatsAppEnabled()) {
    return NextResponse.json({ error: "ربط واتساب غير مفعّل" }, { status: 404 });
  }

  const payload = await req.json();
  const messages = parseIncomingWebhook(payload);

  if (messages.length === 0) {
    return NextResponse.json({ ok: true });
  }

  const supabase = createSupabaseAdminClient();

  for (const msg of messages) {
    const { data: connection } = await supabase
      .from("whatsapp_connections")
      .select("*, businesses(*)")
      .eq("phone_number_id", msg.phoneNumberId)
      .eq("status", "connected")
      .single();

    if (!connection) continue;

    const business = connection.businesses;

    const { data: aiSettings } = await supabase
      .from("ai_settings")
      .select("*")
      .eq("business_id", business.id)
      .single();

    if (!aiSettings) continue;

    await supabase.from("conversation_messages").insert({
      business_id: business.id,
      customer_phone: msg.from,
      direction: "inbound",
      content: msg.text,
    });

    const result = await generateReply(aiSettings, {
      systemPrompt: buildSystemPrompt(business),
      userMessage: msg.text,
    });

    if (result.success && result.reply) {
      await sendWhatsAppMessage({
        phoneNumberId: msg.phoneNumberId,
        accessToken: connection.access_token,
        to: msg.from,
        text: result.reply,
      });

      await supabase.from("conversation_messages").insert({
        business_id: business.id,
        customer_phone: msg.from,
        direction: "outbound",
        content: result.reply,
        provider: result.provider,
      });
    }
  }

  return NextResponse.json({ ok: true });
}
