import { NextRequest, NextResponse } from "next/server";
import { createSupabaseServerClient } from "@/lib/supabase/server";
import { getProvider } from "@/lib/ai/registry";
import type { AIProviderId } from "@/types";

/** يختبر صلاحية مفتاح API لمزود معيّن قبل حفظه. */
export async function POST(req: NextRequest) {
  const supabase = await createSupabaseServerClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    return NextResponse.json({ success: false, error: "غير مصرح" }, { status: 401 });
  }

  const body = await req.json();
  const provider: AIProviderId = body?.provider;
  const apiKey: string = (body?.apiKey ?? "").toString().trim();
  const model: string = (body?.model ?? "").toString().trim();

  if (!provider || !apiKey) {
    return NextResponse.json(
      { success: false, error: "الرجاء اختيار المزود وإدخال مفتاح API" },
      { status: 400 }
    );
  }

  try {
    const impl = getProvider(provider);
    const result = await impl.testConnection(apiKey, model || impl.defaultModel);
    return NextResponse.json(result);
  } catch (err) {
    return NextResponse.json(
      { success: false, error: err instanceof Error ? err.message : "فشل الاختبار" },
      { status: 500 }
    );
  }
}
