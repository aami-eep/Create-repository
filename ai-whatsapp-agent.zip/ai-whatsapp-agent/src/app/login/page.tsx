"use client";

import { useState } from "react";
import Link from "next/link";
import { MessageCircle, Loader2, CheckCircle2 } from "lucide-react";
import { createSupabaseBrowserClient } from "@/lib/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ThemeToggle } from "@/components/theme-toggle";

export default function LoginPage() {
  const [email, setEmail] = useState("");
  const [status, setStatus] = useState<"idle" | "loading" | "sent" | "error">("idle");
  const [error, setError] = useState("");

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setStatus("loading");
    setError("");

    const supabase = createSupabaseBrowserClient();
    const { error } = await supabase.auth.signInWithOtp({
      email,
      options: {
        emailRedirectTo: `${window.location.origin}/api/auth/callback`,
      },
    });

    if (error) {
      setStatus("error");
      setError(error.message);
      return;
    }
    setStatus("sent");
  }

  return (
    <main className="flex min-h-screen flex-col">
      <div className="flex items-center justify-between px-6 py-5">
        <Link href="/" className="flex items-center gap-2">
          <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-ink dark:bg-brand-500 text-canvas-light dark:text-white">
            <MessageCircle size={16} strokeWidth={2.5} />
          </span>
          <span className="font-display text-[15px] font-bold">AI WhatsApp Agent</span>
        </Link>
        <ThemeToggle />
      </div>

      <div className="flex flex-1 items-center justify-center px-6 pb-20">
        <div className="w-full max-w-sm">
          {status === "sent" ? (
            <div className="text-center animate-fadeUp">
              <div className="mx-auto mb-5 flex h-12 w-12 items-center justify-center rounded-full bg-signal-green/10 text-signal-green">
                <CheckCircle2 size={24} />
              </div>
              <h1 className="font-display text-xl font-bold">تحقق من بريدك الإلكتروني</h1>
              <p className="mt-2 text-sm leading-relaxed text-ink-soft">
                أرسلنا رابط تسجيل دخول إلى <span className="text-ink dark:text-ink-inverted">{email}</span>.
                افتح الرابط من نفس الجهاز لإكمال الدخول.
              </p>
            </div>
          ) : (
            <>
              <h1 className="text-center font-display text-2xl font-bold">مرحباً بعودتك</h1>
              <p className="mt-2 text-center text-sm text-ink-soft">
                أدخل بريدك الإلكتروني وسنرسل لك رابط دخول آمن، بدون كلمة مرور.
              </p>

              <form onSubmit={handleSubmit} className="mt-8 space-y-4">
                <div>
                  <Label htmlFor="email">البريد الإلكتروني</Label>
                  <Input
                    id="email"
                    type="email"
                    required
                    placeholder="you@company.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    dir="ltr"
                    className="text-left"
                  />
                </div>

                {status === "error" && (
                  <p className="rounded-lg bg-signal-red/10 px-3 py-2 text-sm text-signal-red">{error}</p>
                )}

                <Button type="submit" className="w-full" size="lg" disabled={status === "loading"}>
                  {status === "loading" ? (
                    <>
                      <Loader2 size={16} className="animate-spin" /> جارٍ الإرسال...
                    </>
                  ) : (
                    "إرسال رابط الدخول"
                  )}
                </Button>
              </form>
            </>
          )}
        </div>
      </div>
    </main>
  );
}
