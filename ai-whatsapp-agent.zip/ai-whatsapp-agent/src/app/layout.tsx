import type { Metadata } from "next";
import { Cairo, JetBrains_Mono } from "next/font/google";
import { ThemeProvider } from "@/components/theme-provider";
import "./globals.css";

const cairo = Cairo({
  subsets: ["arabic", "latin"],
  variable: "--font-display",
  weight: ["400", "500", "600", "700", "800"],
});

const cairoBody = Cairo({
  subsets: ["arabic", "latin"],
  variable: "--font-body",
  weight: ["400", "500", "600"],
});

const mono = JetBrains_Mono({
  subsets: ["latin"],
  variable: "--font-mono",
  weight: ["400", "500"],
});

export const metadata: Metadata = {
  title: "AI WhatsApp Agent | مساعدك الذكي على واتساب",
  description:
    "اربط واتساب بيزنس بالذكاء الاصطناعي وخلّه يرد على عملائك تلقائياً على مدار الساعة.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ar" dir="rtl" suppressHydrationWarning>
      <body className={`${cairo.variable} ${cairoBody.variable} ${mono.variable} font-body`}>
        <ThemeProvider>{children}</ThemeProvider>
      </body>
    </html>
  );
}
