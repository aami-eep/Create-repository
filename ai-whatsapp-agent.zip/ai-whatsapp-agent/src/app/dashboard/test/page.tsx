import { createSupabaseServerClient } from "@/lib/supabase/server";
import { Topbar } from "@/components/dashboard/topbar";
import { TestChat } from "@/components/dashboard/test-chat";

export default async function TestPage() {
  const supabase = await createSupabaseServerClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  return (
    <>
      <Topbar title="صفحة الاختبار" email={user?.email} />
      <div className="mx-auto max-w-2xl p-8">
        <TestChat />
      </div>
    </>
  );
}
