import { createSupabaseServerClient } from "@/lib/supabase/server";
import { Topbar } from "@/components/dashboard/topbar";
import { Card, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { formatDateTime } from "@/lib/utils";
import { Building2, MessageSquare, Radio, Inbox } from "lucide-react";
import Link from "next/link";
import { Button } from "@/components/ui/button";

export default async function DashboardPage() {
  const supabase = await createSupabaseServerClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  const { data: business } = await supabase
    .from("businesses")
    .select("*")
    .eq("owner_id", user!.id)
    .single();

  const { data: whatsapp } = await supabase
    .from("whatsapp_connections")
    .select("status")
    .eq("business_id", business?.id)
    .single();

  const { count: totalReplies } = await supabase
    .from("conversation_messages")
    .select("*", { count: "exact", head: true })
    .eq("business_id", business?.id)
    .eq("direction", "outbound");

  const { data: lastMessages } = await supabase
    .from("conversation_messages")
    .select("*")
    .eq("business_id", business?.id)
    .order("created_at", { ascending: false })
    .limit(6);

  const isConnected = whatsapp?.status === "connected";

  return (
    <>
      <Topbar title="لوحة التحكم" email={user?.email} />

      <div className="grid gap-6 p-8">
        <div className="grid gap-6 md:grid-cols-3">
          <Card>
            <div className="flex items-center gap-3">
              <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-brand-500/10 text-brand-500">
                <Building2 size={18} />
              </span>
              <div>
                <p className="text-xs text-ink-soft">اسم الشركة</p>
                <p className="font-display text-lg font-bold">{business?.name ?? "—"}</p>
              </div>
            </div>
          </Card>

          <Card>
            <div className="flex items-center gap-3">
              <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-brand-500/10 text-brand-500">
                <Radio size={18} />
              </span>
              <div>
                <p className="text-xs text-ink-soft">حالة ربط واتساب</p>
                <Badge tone={isConnected ? "success" : "warning"} className="mt-1">
                  {isConnected ? "متصل" : "غير متصل بعد"}
                </Badge>
              </div>
            </div>
          </Card>

          <Card>
            <div className="flex items-center gap-3">
              <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-brand-500/10 text-brand-500">
                <MessageSquare size={18} />
              </span>
              <div>
                <p className="text-xs text-ink-soft">إجمالي الردود الآلية</p>
                <p className="font-display text-lg font-bold">{totalReplies ?? 0}</p>
              </div>
            </div>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>آخر الرسائل</CardTitle>
          </CardHeader>

          {!lastMessages || lastMessages.length === 0 ? (
            <div className="flex flex-col items-center justify-center gap-3 py-14 text-center">
              <span className="flex h-12 w-12 items-center justify-center rounded-full bg-black/5 dark:bg-white/5 text-ink-soft">
                <Inbox size={20} />
              </span>
              <p className="text-sm text-ink-soft">
                لا توجد رسائل بعد. جرّب الذكاء الاصطناعي من صفحة الاختبار أولاً.
              </p>
              <Link href="/dashboard/test">
                <Button variant="outline" size="sm">
                  الذهاب لصفحة الاختبار
                </Button>
              </Link>
            </div>
          ) : (
            <ul className="divide-y divide-line-light dark:divide-line">
              {lastMessages.map((msg) => (
                <li key={msg.id} className="flex items-start justify-between gap-4 py-3">
                  <div className="flex items-start gap-3">
                    <Badge tone={msg.direction === "inbound" ? "neutral" : "brand"}>
                      {msg.direction === "inbound" ? "عميل" : "الذكاء الاصطناعي"}
                    </Badge>
                    <p className="max-w-md text-sm text-ink dark:text-ink-inverted">{msg.content}</p>
                  </div>
                  <span className="shrink-0 text-xs text-ink-soft">{formatDateTime(msg.created_at)}</span>
                </li>
              ))}
            </ul>
          )}
        </Card>
      </div>
    </>
  );
}
