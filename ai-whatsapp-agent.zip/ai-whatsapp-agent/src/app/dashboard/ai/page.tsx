import { createSupabaseServerClient } from "@/lib/supabase/server";
import { Topbar } from "@/components/dashboard/topbar";
import { AISettingsForm } from "@/components/dashboard/ai-settings-form";

export default async function AISettingsPage() {
  const supabase = await createSupabaseServerClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  const { data: business } = await supabase
    .from("businesses")
    .select("id")
    .eq("owner_id", user!.id)
    .single();

  const { data: settings } = await supabase
    .from("ai_settings")
    .select("*")
    .eq("business_id", business!.id)
    .single();

  return (
    <>
      <Topbar title="إعدادات الذكاء الاصطناعي" email={user?.email} />
      <div className="p-8">{settings && <AISettingsForm settings={settings} />}</div>
    </>
  );
}
