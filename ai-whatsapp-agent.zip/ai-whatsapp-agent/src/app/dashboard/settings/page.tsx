import { createSupabaseServerClient } from "@/lib/supabase/server";
import { Topbar } from "@/components/dashboard/topbar";
import { BusinessForm } from "@/components/dashboard/business-form";

export default async function SettingsPage() {
  const supabase = await createSupabaseServerClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  const { data: business } = await supabase
    .from("businesses")
    .select("*")
    .eq("owner_id", user!.id)
    .single();

  return (
    <>
      <Topbar title="إعدادات الشركة" email={user?.email} />
      <div className="p-8">{business && <BusinessForm business={business} />}</div>
    </>
  );
}
