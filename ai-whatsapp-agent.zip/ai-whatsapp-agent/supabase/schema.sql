-- ============================================================================
-- AI WhatsApp Agent - Supabase Schema
-- انسخ هذا الملف بالكامل وشغّله في: Supabase Dashboard > SQL Editor > New query
-- ============================================================================

-- 1) جدول الشركات (كل مستخدم مسجّل دخول يملك شركة واحدة في النسخة الأولى)
create table if not exists public.businesses (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users (id) on delete cascade,
  name text not null default 'شركتي',
  description text,
  services text,
  products text,
  prices text,
  faq text,
  working_hours text,
  location text,
  phone text,
  ai_instructions text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (owner_id)
);

-- 2) جدول إعدادات الذكاء الاصطناعي (مفصول عن الشركة لسهولة التوسّع لاحقاً)
create table if not exists public.ai_settings (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses (id) on delete cascade,
  provider text not null default 'gemini' check (provider in ('gemini', 'qwen', 'deepseek')),
  gemini_api_key text,
  qwen_api_key text,
  deepseek_api_key text,
  gemini_model text,
  qwen_model text,
  deepseek_model text,
  is_connected boolean not null default false,
  updated_at timestamptz not null default now(),
  unique (business_id)
);

-- 3) جدول ربط واتساب (جاهز للاستخدام لاحقاً - غير مفعّل في النسخة الأولى)
create table if not exists public.whatsapp_connections (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses (id) on delete cascade,
  phone_number_id text,
  waba_id text,
  access_token text,
  verify_token text,
  status text not null default 'disconnected'
    check (status in ('disconnected', 'pending', 'connected', 'error')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (business_id)
);

-- 4) سجل الرسائل (يُستخدم لعرض "آخر الرسائل" و"عدد الردود" في لوحة التحكم)
create table if not exists public.conversation_messages (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses (id) on delete cascade,
  customer_phone text not null,
  direction text not null check (direction in ('inbound', 'outbound')),
  content text not null,
  provider text check (provider in ('gemini', 'qwen', 'deepseek')),
  created_at timestamptz not null default now()
);

create index if not exists conversation_messages_business_id_idx
  on public.conversation_messages (business_id, created_at desc);

-- ============================================================================
-- Row Level Security: كل مستخدم يرى فقط بيانات شركته الخاصة
-- ============================================================================

alter table public.businesses enable row level security;
alter table public.ai_settings enable row level security;
alter table public.whatsapp_connections enable row level security;
alter table public.conversation_messages enable row level security;

create policy "select_own_business" on public.businesses
  for select using (auth.uid() = owner_id);
create policy "insert_own_business" on public.businesses
  for insert with check (auth.uid() = owner_id);
create policy "update_own_business" on public.businesses
  for update using (auth.uid() = owner_id);

create policy "select_own_ai_settings" on public.ai_settings
  for select using (
    exists (select 1 from public.businesses b where b.id = business_id and b.owner_id = auth.uid())
  );
create policy "insert_own_ai_settings" on public.ai_settings
  for insert with check (
    exists (select 1 from public.businesses b where b.id = business_id and b.owner_id = auth.uid())
  );
create policy "update_own_ai_settings" on public.ai_settings
  for update using (
    exists (select 1 from public.businesses b where b.id = business_id and b.owner_id = auth.uid())
  );

create policy "select_own_whatsapp" on public.whatsapp_connections
  for select using (
    exists (select 1 from public.businesses b where b.id = business_id and b.owner_id = auth.uid())
  );
create policy "insert_own_whatsapp" on public.whatsapp_connections
  for insert with check (
    exists (select 1 from public.businesses b where b.id = business_id and b.owner_id = auth.uid())
  );
create policy "update_own_whatsapp" on public.whatsapp_connections
  for update using (
    exists (select 1 from public.businesses b where b.id = business_id and b.owner_id = auth.uid())
  );

create policy "select_own_messages" on public.conversation_messages
  for select using (
    exists (select 1 from public.businesses b where b.id = business_id and b.owner_id = auth.uid())
  );
create policy "insert_own_messages" on public.conversation_messages
  for insert with check (
    exists (select 1 from public.businesses b where b.id = business_id and b.owner_id = auth.uid())
  );

-- ============================================================================
-- Trigger: عند تسجيل مستخدم جديد، أنشئ له تلقائياً شركة + إعدادات ذكاء اصطناعي
-- ============================================================================

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
declare
  new_business_id uuid;
begin
  insert into public.businesses (owner_id, name)
  values (new.id, 'شركتي الجديدة')
  returning id into new_business_id;

  insert into public.ai_settings (business_id, provider)
  values (new_business_id, 'gemini');

  insert into public.whatsapp_connections (business_id, status)
  values (new_business_id, 'disconnected');

  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- ============================================================================
-- Trigger: تحديث updated_at تلقائياً
-- ============================================================================

create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists set_businesses_updated_at on public.businesses;
create trigger set_businesses_updated_at
  before update on public.businesses
  for each row execute function public.set_updated_at();

drop trigger if exists set_ai_settings_updated_at on public.ai_settings;
create trigger set_ai_settings_updated_at
  before update on public.ai_settings
  for each row execute function public.set_updated_at();

drop trigger if exists set_whatsapp_updated_at on public.whatsapp_connections;
create trigger set_whatsapp_updated_at
  before update on public.whatsapp_connections
  for each row execute function public.set_updated_at();
